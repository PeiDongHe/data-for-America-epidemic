import pandas as pd
import os
import numpy as np
import time
#导入四个包
#定义一个func2函数
def func1(x,k):
    '''
    Parameters
    ----------
    x : str. original strings, eg: Com_EmployNum_12
    k : str. keyword, eg: Com_EmployNum

    Returns
    -------
    str.
    It returns a standard format of quarter_to_the_event_date, eg:
        Com_EmployNum returns 0
        Com_EmployNum_12 returns 12
        Com_EmployNum__12 returns -12
    '''
    n = len(k)
    if x[n:]=='':
        return 0
    elif x[n:][0:2]=='__':
        return -1*int(x[n+2:])
    return int(x[n+1:])
    
if __name__ == '__main__':
    #记录程序开始的时间为a
    a = time.time()
    # 这将返回此文件的绝对路径：即data_trans.csv，连同 deal_level_data.csv 和 quad_level_data.csv
    path = os.path.abspath(os.path.dirname(__file__))
    data = pd.read_csv(path+'/7033FengSibo3035886831/project3/deal_level_data.csv',encoding="utf_8")
    template = pd.read_csv(path+'/7033FengSibo3035886831/project3/quarter_level_data.csv',encoding="utf_8")
    #template 的列（columns）记录输出文件所需的顺序
    template_columns = template.columns.values
    #对于下面的部分，我们得到三个列表，它们分别包含三个部分的列
    #column_index 是从开始到季度前的列
    column_index=[]
    #遍历data的columns数值
    for i in data.columns.values:
        #对于以‘quarter’开头的元素将其加入到column_index中
        if i[:7]!='quarter':
            column_index.append(i)
        else:
            break
    # column_quarter contains columns with 'quarter'
    column_quarter = [i for i in data.columns.values if i[:7]=='quarter']
    #column_indicator 包含包含“Com”和“Tar”的左列，但不包括那些以 Com_EmployNum_12 等数字结尾的
    column_indicator = [i for i in data.columns.values if i not in column_index 
                        and i not in column_quarter and i[-1].isalpha() and (i[:3]=='Com'or i[:3]=='Tar')]
    # dist_indicator 记录不同指标的列名。
    # 键是指标名称，如 Com_EmployNum；
    # 值是它们的子集，如 Com_EmployNum_12、Com_EmployNum_12 等
    # 每一项的长度为25（-12到12）
    dist_indicator={}
    for i in column_indicator:
        dist_indicator[i]=[j for j in data.columns.values if j==i]
        for j in data.columns.values:
            if len(j)>len(i)+1:
                if i in j and not j[len(i)+1].isalpha():
                    dist_indicator[i].append(j)
# =============================================================================
# Then we do the transformation part, which is implemented mainly by stack and merge methods
# 然后我们做转换部分，主要通过stack和merge方法实现
# =============================================================================
    # 首先我们堆叠四分之一的部分
    df = data.set_index(['Deal_Number'])[column_quarter].stack().reset_index(name='quarter')
    #将level_1 重新命名为quarter_to_the_event_date
    df = df.rename(columns={'level_1':'quarter_to_the_event_date'})
    #对quarter_to_the_event_date这一列使用func1函数（前面定义）
    df['quarter_to_the_event_date'] = df['quarter_to_the_event_date'].apply(lambda x: func1(x,'quarter'))
    #将df通过'Deal_Number','quarter_to_the_event_date'进行排列，并重新设置序号
    df = df.sort_values(by=['Deal_Number','quarter_to_the_event_date']).reset_index(drop=True)
    # 其次，我们堆叠指标的部分，并将每个指标合并到季度的部分
    #遍历dist_indicator中的keys
    for key in dist_indicator.keys():
        #将‘Deal_Number’设置参数，并将dist_indicater[key]重新设置参数为key
        df_ = data.set_index(['Deal_Number'])[dist_indicator[key]].stack().reset_index(name=key)
        #将level_1 重新命名为'quarter_to_the_event_date'
        df_ = df_.rename(columns={'level_1':'quarter_to_the_event_date'})
        #对quarter_to_the_event_date这一列使用func1函数（前面定义）
        df_['quarter_to_the_event_date'] = df_['quarter_to_the_event_date'].apply(lambda x: func1(x,key))
        #将df通过'Deal_Number','quarter_to_the_event_date'进行排列，并重新设置序号
        df_ = df_.sort_values(by=['Deal_Number','quarter_to_the_event_date']).reset_index(drop=True)
        df = df.merge(df_,how='outer')
    # 最后将其合并到固定列（column_index）并根据模板列重置列的顺序
    df = data[column_index].merge(df)[template_columns].set_index('Deal_Number')
    # print(df)
    b = time.time()
    #打印总共使用的时间
    print('total transforming time is ',b-a) # around 2.2s
    #文件保存输出到output的csv文件中
    df.to_csv(path+'/7033FengSibo3035886831/project3/output.csv',encoding="utf_8")
    #打印保存花费的时间
    print('total saving time is ',time.time()-b) # around 33s
    
