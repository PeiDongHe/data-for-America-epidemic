#!/usr/bin/env python
# coding: utf-8

# In[21]:


from datetime import datetime
import pandas as pd
#导入datatime和pandas模块

#读取名叫ukpound_exchange的csv文件，删除第一列
ukpound_exchange = pd.read_csv('/Users/fengsibo/Desktop/7033FengSibo3035886831/project4/ukpound_exchange.csv',index_col=0)
#将文件Date一列的日期格式改成yyyy-mm-dd的形式，如1983-10-11
ukpound_exchange['Date'] = ukpound_exchange['Date'].apply(lambda x: datetime.strptime(x,'%m/%d/%Y'))
#将文件按日期为单位进行重新采样，并设置表头名称为DATA，保存到名叫output的csv中
ukpound_exchange.resample('M',on='Date').last().set_index('Date').to_csv('/Users/fengsibo/Desktop/7033FengSibo3035886831/project4/output.csv')


# In[22]:


ukpound_exchange.head(20)


# In[20]:


ukpound_exchange.head(20)

