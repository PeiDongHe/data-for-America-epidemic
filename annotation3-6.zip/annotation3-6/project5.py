import pandas as pd
from geopy.geocoders import TomTom
from geopy.distance import geodesic
#导入三个模块
#调用geopy.geocoders 的TomTom 模块，可以从API中检索TomTom的地理编码数据
geolocator = TomTom(api_key="LXLbUei32cW7clObVDOG36G6Ycr4ViAu")

#输入白宫的经纬度
white_house = (38.8976763, -77.0387185) 
#读取命名为coname_addersses的excel，去除第一列
true coname_addresses = pd.read_excel('/Users/fengsibo/Desktop/7033FengSibo3035886831/project5/coname_addresses.xlsx',index_col=0)

# print(coname_addresses.index.values)
#增加三列，分别命名为'lat','lng'和‘distance'
coname_addresses['lat']=''
coname_addresses['lng']=''
coname_addresses['distance']=''
#对于所有的coname_addresses的指数值
for i in coname_addresses.index.values:
    #令add为文件中‘address’列的第i行
    add = coname_addresses.loc[i,'address']
    #输出i，和add
    print(i, add)
    # if math.isnan(float(add)):
    #     continue
    #获得add的位置信息，如果位置信息为空，则输出不能找到add的坐标，如果不为空，则将对应的经纬度信息赋给'lat'和‘lng’列
    try:
        location = geolocator.geocode(add)
    except :
        continue
    if location == None:
        print('Cannot find the location of ', add)
        continue
    coname_addresses.loc[i,'lat'] = location.latitude
    coname_addresses.loc[i,'lng'] = location.longitude
    #将距离白宫的距离以miles为单位放到distance这列数据中
    coname_addresses.loc[i,'distance'] = geodesic((location.latitude, location.longitude), white_house).miles
#保存到命名为output的excel中
coname_addresses.to_excel('/Users/fengsibo/Desktop/7033FengSibo3035886831/project5/output.xlsx')

