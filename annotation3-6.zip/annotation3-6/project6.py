import csv, time, os
from multiprocessing import Pool
from fuzzywuzzy import fuzz,process
import pandas as pd
#导入相应的模块

#输入基础的路径
#base_path = r'/Users/fengsibo/Desktop/7033FengSibo3035886831/project6'
base_path = r'/Users/hepeidong/Documents/Xianyu/11月/11.23-注释-150/6'

#确定输出文件的路径及名字
saved_file_name = base_path + os.sep + 'output.csv'

#定义mainFunction函数
#输入为data_firm 和 firm_list
def mainFunction(data_firm,firm_list):
    #打开路径为saved_file_name文件
    csvfile = open(saved_file_name, 'a+', newline='')
    #用writer函数运行，csvfile文件，分隔符记为‘，’ 引用字符为'|'，引用csv的最小值
    linewriter = csv.writer(csvfile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    #对于firm_list中的所有元素
    for firm in firm_list:
        #需要添加process.extract提取firm元素和data_firm元素，令限制为5，scorer为fuzz.partial_ratio得到的matches 并取matches的第一个元素
        #进行writerow操作
        linewriter.writerow([matches[0] for matches in process.extract(firm, data_firm, limit=5, scorer=fuzz.partial_ratio)])
    csvfile.close()

        
#表示函数开始运行
if __name__ == '__main__':
    #第一个列为文件acquires的‘Acquirer Name’这一列，并将其转换为list的形式
    firm_list = pd.read_excel(base_path + os.sep + 'acquirers.xlsx')['Acquirer Name'].tolist()
    #data_firm 为文件bank_names的'bank_names‘这一列
    data_firm = pd.read_csv(base_path + os.sep + 'bank_names.csv')['bank_names']
    #将data_firm中的，和|符号均替换成空格，并将其转换为list的形式
    data_firm = data_firm.str.replace(',',' ').replace('|',' ').tolist()
    # print(data_firm)
    #记录开始时间
    start_time = time.time()
    #打开output文件
    csvfile = open(saved_file_name, 'a+', newline='')
    #用writer函数运行，csvfile文件，分隔符记为‘，’ 引用字符为'|'，引用csv的最小值
    linewriter = csv.writer(csvfile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    #添加行 分别为'acquirers','0','1','2','3','4'
    linewriter.writerow(['acquirers','0','1','2','3','4'])
    #关闭csv文件
    csvfile.close()
#    p = Pool(processes=4)
#    p.map(mainFunction,data_firm,firm_list)
    #运行mainFunction函数
    mainFunction(data_firm,firm_list)
    #打印运行时间，即结束时间减去开始时间
    print("--- %s seconds ---" % (time.time() - start_time))
    
